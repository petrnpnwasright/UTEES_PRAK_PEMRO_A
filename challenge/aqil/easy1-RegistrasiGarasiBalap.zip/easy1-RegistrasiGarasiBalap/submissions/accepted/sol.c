#include <stdio.h>

int main() {
    int NomorMobil, NomorGarasi;

    scanf("%d", &NomorMobil);
    scanf("%d", &NomorGarasi);

    printf("Mobil Balap: %d\n", NomorMobil);
    printf("Lokasi Garasi: %d\n", NomorGarasi);

    return 0;
}
