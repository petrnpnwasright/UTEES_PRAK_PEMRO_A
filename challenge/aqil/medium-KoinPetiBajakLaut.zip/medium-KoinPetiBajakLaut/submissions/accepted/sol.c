#include <stdio.h>

int main() {
    int n;
    int koin[100];
    int total_koin = 0;
    int max_koin = -1;
    int peti_terkaya = 0;

    scanf("%d", &n);
    
    for(int i = 0; i < n; i++) {
        scanf("%d", &koin[i]);
        total_koin += koin[i];
        
        if(koin[i] > max_koin) {
            max_koin = koin[i];
            peti_terkaya = i + 1;
        }
    }
    
    printf("Total Koin: %d\n", total_koin);
    printf("Peti Terkaya: %d\n", peti_terkaya);
    
    return 0;
}
