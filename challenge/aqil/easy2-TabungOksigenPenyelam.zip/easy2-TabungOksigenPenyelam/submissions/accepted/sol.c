#include <stdio.h>

int main() {
    float R, T, V;

    scanf("%f", &R);
    scanf("%f", &T);

    V = 3.14 * R * R * T;

    printf("Volume Tabung: %.2f\n", V);

    return 0;
}
