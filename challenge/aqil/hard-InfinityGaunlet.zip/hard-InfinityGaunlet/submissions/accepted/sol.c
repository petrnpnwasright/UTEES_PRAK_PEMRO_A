#include <stdio.h>

int main() {
    int n;
    int energi[100];
    int *ptr = energi;
    int tambahan;

    scanf("%d", &n);
    for(int i = 0; i < n; i++) {
        scanf("%d", &energi[i]);
    }
    
    scanf("%d", &tambahan);
    for(int i = 0; i < n; i++) {
        *(ptr + i) += tambahan;
    }
    
    for(int i = 0; i < n; i++) {
        printf("[%d] ", *(ptr + i));
    }
    printf("\n");
    
    return 0;
}
