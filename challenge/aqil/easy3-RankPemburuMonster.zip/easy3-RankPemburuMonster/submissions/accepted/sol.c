#include <stdio.h>

int main() {
    int Point;

    scanf("%d", &Point);

    if (Point < 100) {
        printf("Rank: Pemula\n");
    } else if (Point <= 499) {
        printf("Rank: Bronze\n");
    } else if (Point <= 999) {
        printf("Rank: Silver\n");
    } else {
        printf("Rank: Gold\n");
    }

    return 0;
}
