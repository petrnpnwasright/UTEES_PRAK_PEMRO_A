#include <stdio.h>

int main() {
    int id, kode;

    scanf("%d", &id);
    scanf("%d", &kode);

    printf("ID Anggota: %d\n", id);
    printf("Kode Lencana: %d\n", kode);

    return 0;
}
