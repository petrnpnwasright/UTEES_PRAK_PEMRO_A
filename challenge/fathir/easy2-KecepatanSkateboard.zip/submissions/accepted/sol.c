#include <stdio.h>

int main() {
    int S, V;

    scanf("%d", &S);
    scanf("%d", &V);

    printf("Waktu: %d jam\n", S / V);

    return 0;
}
