#include <stdio.h>

int main() {
    int N;
    scanf("%d", &N);

    int A[N];
    int ditemukan = 0;

    for (int i = 0; i < N; i++) {
        scanf("%d", &A[i]);
    }

    for (int i = 0; i < N; i++) {
        if (A[i] % 2 == 0) {
            if (ditemukan) {
                printf(" ");
            }
            printf("%d", A[i]);
            ditemukan = 1;
        }
    }

    if (!ditemukan) {
        printf("Tidak Ada Petunjuk");
    }

    printf("\n");

    return 0;
}
