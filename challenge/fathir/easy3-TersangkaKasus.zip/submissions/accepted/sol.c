#include <stdio.h>

int main() {
    int jarak;

    scanf("%d", &jarak);

    if (jarak <= 5) {
        printf("Status: Tersangka\n");
    } else if (jarak <= 15) {
        printf("Status: Saksi Kunci\n");
    } else {
        printf("Status: Bebas\n");
    }

    return 0;
}
